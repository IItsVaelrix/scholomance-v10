export const SCROLL_LIMITS = {
  title: 100,
  content: 100000,
};
